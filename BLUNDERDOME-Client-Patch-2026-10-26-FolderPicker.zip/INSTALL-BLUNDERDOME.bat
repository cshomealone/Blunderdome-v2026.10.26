@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Install-BLUNDERDOME.ps1" %*
if errorlevel 1 (
  echo.
  echo Installation failed. Read the error above and check README-FIRST.txt.
)
echo.
pause
endlocal