BLUNDERDOME CLIENT PATCH - 2026-10-26

INSTALL
1. Extract this entire ZIP to a normal folder.
2. Make or use a separate copy of your supported Rain of Fear 2 client for this server.
3. Close EverQuest if it is running from that client folder.
4. Run INSTALL-BLUNDERDOME.bat and select the separate client folder in the folder browser.
5. After the installer reports success, run Play-BLUNDERDOME.bat from inside that client folder.
6. Use your PUBLIC EQEmu login account and select:
   CSHOME ALONE : PvPresents Blunderdome

INSTALLER BEHAVIOR
- Installs both the core client files and Default UI files from this single package.
- Checks the target is a supported RoF2 client and verifies every packaged file before installing.
- Overwrites matching files directly. It does not create backup files or backup folders.
- Adds the required Guide Djeph model line to Resources\GlobalLoad.txt if it is not already present.
- Use a separate client copy. Files overwritten by the installer cannot be restored from this package.

REQUIREMENTS / NOTES
- This is a patch, not a complete EverQuest installation.
- The server is initially locked for owner testing; the client patch does not grant GM access.
- Use the Default UI. A custom skin may not support the included loot interface.
- Do not run LaunchPad or the official EverQuest patcher with this client copy.
- The package includes a server-specific eqgame.exe and login configuration. Keep this client copy for Blunderdome.
- Packaging and file-integrity checks do not replace an outside-player login and zoning test.