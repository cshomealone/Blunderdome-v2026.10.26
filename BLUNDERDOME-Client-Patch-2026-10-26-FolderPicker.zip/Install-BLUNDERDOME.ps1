param([string]$ClientPath)
$ErrorActionPreference = 'Stop'
try {
    if ([string]::IsNullOrWhiteSpace($ClientPath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select the RoF2 EverQuest client folder containing eqgame.exe.'
        $dialog.ShowNewFolderButton = $false
        $dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
        $dialog.SelectedPath = [Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            $dialog.Dispose()
            Write-Host 'Installation cancelled.'
            exit 0
        }
        $ClientPath = $dialog.SelectedPath
        $dialog.Dispose()
    }
    $ClientPath = $ClientPath.Trim().Trim('"')
    $target = (Resolve-Path -LiteralPath $ClientPath -ErrorAction Stop).Path.TrimEnd('\')
    if (!(Test-Path -LiteralPath (Join-Path $target 'eqgame.exe') -PathType Leaf)) {
        throw 'Choose an existing RoF2 client folder containing eqgame.exe.'
    }
    $globalLoad = Join-Path $target 'Resources\GlobalLoad.txt'
    if (!(Test-Path -LiteralPath $globalLoad -PathType Leaf)) {
        throw 'This RoF2 client is incomplete: Resources\GlobalLoad.txt is missing.'
    }

    $supported = @(
        'C4018F1606072BBE7A20AFD2A090FA2FAF9D75CEC4356A5EB9F60CBCFCBBA117',
        'AB5A96975BC665FDD14677E8331496BF1BA4176ECC4A28BD58C10427FCC8CBAE',
        '2A8702AD9F722704F01355C0750BE7D6F164A8B9C9128BA0CF286EA32B405B0E',
        '025171B50538F573D4C1E637FBBB387E6C1850A0B03769ADC09F30C1605B7133'
    )
    $clientHash = (Get-FileHash -LiteralPath (Join-Path $target 'eqgame.exe') -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($clientHash -notin $supported) {
        throw 'Unsupported eqgame.exe. This package requires one of the supported RoF2 clients; do not install it into Titanium or a current Live client.'
    }
    foreach ($process in @(Get-Process -Name eqgame -ErrorAction SilentlyContinue)) {
        if (!$process.Path -or $process.Path -ieq (Join-Path $target 'eqgame.exe')) {
            throw 'Close the EverQuest client using this folder, then run the installer again.'
        }
    }

    $manifestPath = Join-Path $PSScriptRoot 'manifest.json'
    $payload = Join-Path $PSScriptRoot 'payload'
    if (!(Test-Path -LiteralPath $manifestPath -PathType Leaf) -or !(Test-Path -LiteralPath $payload -PathType Container)) {
        throw 'Package files are missing. Extract the complete combined ZIP before running the installer.'
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    if (!$manifest.Files -or $manifest.Files.Count -eq 0) { throw 'The package manifest contains no files.' }

    # Validate all source hashes and destination paths before writing anything.
    foreach ($file in $manifest.Files) {
        $relative = $file.Path.Replace('/', '\')
        if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|\\)\.\.(\\|$)') {
            throw "Invalid package destination: $relative"
        }
        $destination = [IO.Path]::GetFullPath((Join-Path $target $relative))
        if (!$destination.StartsWith($target + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw "Invalid package destination: $relative"
        }
        $source = Join-Path $payload $relative
        if (!(Test-Path -LiteralPath $source -PathType Leaf)) {
            throw "Package file missing: $relative. Extract the complete combined ZIP again."
        }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $file.SHA256) {
            throw "Package integrity check failed: $relative. Extract the complete combined ZIP again."
        }
        if ((Test-Path -LiteralPath $destination) -and (Test-Path -LiteralPath $destination -PathType Container)) {
            throw "A folder conflicts with the required file destination: $relative"
        }
    }

    foreach ($file in $manifest.Files) {
        $relative = $file.Path.Replace('/', '\')
        $destination = Join-Path $target $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $payload $relative) -Destination $destination -Force
    }

    $globalText = [IO.File]::ReadAllText($globalLoad)
    if ($globalText -notmatch '(?im)^\s*\d+,\d+,[^,]+,bothunder_chr\s*,') {
        [IO.File]::AppendAllText($globalLoad, "`r`n3,0,TFFFC,bothunder_chr,Loading Emmerik GM Skin`r`n", [Text.Encoding]::ASCII)
    }
    foreach ($file in $manifest.Files) {
        $relative = $file.Path.Replace('/', '\')
        if ((Get-FileHash -LiteralPath (Join-Path $target $relative) -Algorithm SHA256).Hash -ne $file.SHA256) {
            throw "Installed file verification failed: $relative"
        }
    }
    Write-Host 'BLUNDERDOME installed successfully. Existing matching files were overwritten; no backups were created.' -ForegroundColor Green
    Write-Host "Launch $(Join-Path $target 'Play-BLUNDERDOME.bat') and use your PUBLIC EQEmu login account."
    Write-Host 'Use the Default UI. If the server says Locked, ordinary accounts cannot enter yet.'
} catch {
    Write-Host ('INSTALL FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}