@echo off
cd /d "%~dp0"
start "" "%~dp0eqgame.exe" patchme
